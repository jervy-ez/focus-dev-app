// Instance the tour
var tour = new Tour({

	steps : [{
		element : ".tour-1",
		title : "Page Header",
		placement : "bottom",
		backdrop : false,
		content : "Hi there! Let me start here. This is the title bar, this displays the current date and page title."
	},{
		element : ".tour-2",
		placement : "right",
		backdrop : false,
		title : "The Sidebar",
		content : "This is the sidebar, this is where all the main links of our programs."
	},{
		element : ".tour-3",
		placement : "bottom",
		backdrop : false,
		title : "The Title Bar Link",
		content : "Well the truth is aesthetically without this bar the design looks inbalance, so I placed some links for other features such as tour."
	},{
		element : ".tour-4",
		placement : "top",
		backdrop : false,
		title : "The Alerts Bar",
		content : "This bar only appears when a error occurs and for general notifications. This can be dismissed."
	},{
		element : ".tour-5",
		placement : "bottom",
		backdrop : false,
		title : "Widgets",
		content : "The widgets will display thier respective contents. Soon Jervy will make lots of this for different user types."
	},{
		element : ".tour-6",
		placement : "left",
		backdrop : false,
		title : "User Account",
		content : "You can access your account details and more more cool stuff here."
	},{
		element : ".tour-7",
		placement : "bottom",
		backdrop : false,
		title : "Thanks!!!",
		content : "I guess it's good bye for me, so long and have a nice day!."
	}]
});

// if( $('#loginModal').is(':empty') ) {
//$('#loginModal').modal('show');
//}

// Initialize the tour
tour.init();

$('.start-tour').click(function(e) {
	tour.restart();
	//tour.start();

	// it's also good practice to preventDefault on the click event
	// to avoid the click triggering whatever is within href:
	e.preventDefault();
});