// google maps setup
var center = new google.maps.LatLng(-25.053169, 133.867844);
// Default center area of map ex:AUS
var map = new google.maps.Map(document.getElementById('map'), {
	zoom : 4,
	minZoom : 4,
	maxZoom : 11,
	disableDefaultUI : true,
	center : center,
	mapTypeId : google.maps.MapTypeId.ROADMAP
});
var markers = [];
var count = data.count;
for (var i = 0; i < count; i++) {
	var dataLocation = data.locations[i];
	var latLng = new google.maps.LatLng(dataLocation.latitude, dataLocation.longitude);
	var marker = new google.maps.Marker({
		position : latLng,
		map : map
	});
	markers.push(marker);
}
var markerCluster = new MarkerClusterer(map, markers);
// google maps setup



