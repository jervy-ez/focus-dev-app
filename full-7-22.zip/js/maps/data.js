var data = { "count": 11,"locations":[
{"longitude": 116.904953, "latitude": -31.323058}
,
{"longitude": 116.113938, "latitude": -32.849515}
,
{"longitude":  115.235031, "latitude": -30.000054}
,
{"longitude":138.438157, "latitude": -17.316462}
,
{"longitude": 139.580735, "latitude": -17.944676}
,
{"longitude": 135.581711, "latitude": -32.664731}
,
{"longitude": 151.007095, "latitude": -33.975601}
,
{"longitude": 151.160904, "latitude": -32.893777}
,
{"longitude": 150.611588, "latitude": -34.266642}
,
{"longitude": 151.248795, "latitude": -32.746055}
,
{"longitude": 133.538834, "latitude": -31.854587}
]}