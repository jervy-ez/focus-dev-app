    //dynamic_value_ajax
    function ajax_data(value,controller_method,classLocation){
      // controller_method class/methodtho
      $.ajax({
        'url' : base_url+controller_method,
        'type' : 'POST',
        'data' : {'ajax_var' : value },
        'success' : function(data){
          var divLocation = $(classLocation);
          if(data){
            divLocation.html(data);
          }
        }
      });
    }
    //dynamic_value_ajax
function site_start_onDateChange() {
  var proj_date = document.getElementById('project_date').value;
  var proj_date_parts = proj_date.split('/');
  proj_date = new Date(proj_date_parts[2],proj_date_parts[1]-1,proj_date_parts[0]); 
  var site_date = document.getElementById('site_start').value;
  var site_date_parts = site_date.split('/');
  site_date = new Date(site_date_parts[2],site_date_parts[1]-1,site_date_parts[0]); 
  if(proj_date > site_date){
    alert("Site Start Date cannot be later than the project Date");
    document.getElementById('site_start').value = "";
  }
}
function site_finish_onDateChange() {
  var proj_date = document.getElementById('project_date').value;
  var proj_date_parts = proj_date.split('/');
  proj_date = new Date(proj_date_parts[2],proj_date_parts[1]-1,proj_date_parts[0]); 
  var site_finish = document.getElementById('site_finish').value;
  var site_finish_parts = site_finish.split('/');
  site_finish = new Date(site_finish_parts[2],site_finish_parts[1]-1,site_finish_parts[0]); 
  var site_date = document.getElementById('site_start').value;
  var site_date_parts = site_date.split('/');
  site_date = new Date(site_date_parts[2],site_date_parts[1]-1,site_date_parts[0]); 
  if(proj_date > site_finish){
    alert("Site Finish Date cannot be later than the project Date");
    document.getElementById('site_finish').value = "";
  }else{
    if(site_date > site_finish){
      alert("Site Finish Date cannot be later than the Site Start Date");
      document.getElementById('site_finish').value = "";
    }
  }
}
var work_id = 0;
var work_contractor_id = 0;
var selected_work_contractor_id = 0;
var company_id = 0;
$(document).ready(function() {
  $("#show1").hide();
  $("#show2").hide();
  $("#show3").hide();
  $("#show4").hide();


  $("#edit_est_markup").show();
  $("#save_est_markup").hide();

  $("#edit_work_dates").show();
  $("#save_work_dates").hide();

  $("#edit_considerations").show();
  $("#save_considerations").hide();

  $("#edit_notes").show();
  $("#save_notes").hide();

  $("#btn_select_subcontractor").hide();
  $("#worktype").change(function(){
    var wtype = $("#worktype").val();
    if(wtype == "Supplier"){
      $("#show1").hide();
      $("#show2").hide();
      $("#show3").show();
      $("#show4").show();
      $('#works').empty();
      $.post(baseurl+"works/diplay_sup_cat", 
      { 
      }, 
      function(result){
        $("#works").html(result);
      });
    }else{
      $("#show1").show();
      $("#show2").show();
      $("#show3").show();
      $("#show4").show();
      $('#works').empty();
      $("#works").text("");
    }
  });

  $("#work_estimate").keyup(function(){
    var quote = 0;
    var w_markup = $("#work_markup").val();
    if(w_markup > 0){
      quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#work_markup").val())/100));
    }else{
      quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#projmarkup").val())/100));
    }

    $("#work_quote_val").val(quote);

    var gst = $("#gst").val();
    var inc_gst = (quote* (gst/100) )+quote;
    $('.inc_gst').val(inc_gst);
  })


  $("#work_markup").blur(function(){
    var minmarkup = $("#minmarkup").val()-0;
    var markup = $("#work_markup").val();
    if(markup < minmarkup){
      alert("Mark Up entered is lower than the minimum value allowed!");
      $("#work_markup").val("");
    }else{
       var quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#work_markup").val())/100));
       $("#work_quote_val").val(quote);
      /*var quote = 0;
      var w_markup = $("#work_markup").val();
      if(w_markup > 0){
        quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#work_markup").val())/100));
      }else{
        quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#projmarkup").val())/100));
      }
      $("#work_quote_val").val(quote);

      var gst = $("#gst").val();
      var inc_gst = (quote* (gst/100) )+quote;
      $('.inc_gst').text(inc_gst);
  */
    }

    
  });

  $("#sel_job_cat").change(function(){
    var selectedval = $(this).val();
    $('#works').empty();
    $.post(baseurl+"works/display_job_sub_cat", 
    { 
      job_cat: selectedval
    }, 
    function(result){
      $("#works").html(result);
    });
  });

  $('#site_start').bind('changeDate', site_start_onDateChange);
  $('#site_finish').bind('changeDate', site_finish_onDateChange);
 
 
  $('#street').keyup(function(evt){
    var txt = $(this).val();
    $(this).val(txt.replace(/^(.)|\s(.)/g, function($1){ return $1.toUpperCase( ); }));
  });

  $("#client_po").blur(function(){
    var formattedDate = new Date();
    var d = formattedDate.getDate();
    var m =  formattedDate.getMonth();
    m += 1;  // JavaScript months are 0-11
    var y = formattedDate.getFullYear();
    $("#job_date").val(d+"/"+m+"/"+y);
  });

  //=== Works JS ====
  $("#btnaddcontractor").hide();
  $("#btnaddcontractor").click(function(){
    var formattedDate = new Date();
    var d = formattedDate.getDate();
    var m =  formattedDate.getMonth();
    m += 1;  // JavaScript months are 0-11
    var y = formattedDate.getFullYear();
    $("#contractor_date_entered").val(d+"/"+m+"/"+y);

    $("#work_contructor_name").val("");

    //$("select#work_contructor_name").val("");
    $("#contact_person").empty();
    $("#inc_gst").val("");
    $("#price_ex_gst").val("");
    $("#save_contractor").show();
    $("#update_contractor").hide();
    $("#delete_contractor").hide();
  });
  window.selwork = function(a){
    work_id = a;
    selected_work_contractor_id = 0;
    $.post(baseurl+"works/display_work_contractor", 
    { 
      work_id: a
    }, 
    function(result){
      $("#work_contractors").html(result);
      $("#btn_select_subcontractor").show();
      $("#cont_cpono").html(work_id);
      $("#btnaddcontractor").show();
    });
    return false;
  }

  $("#inc_gst").keyup(function(){
    var inc_gst = $("#inc_gst").val();
    $.post(baseurl+"works/fetch_gst_rate", 
    { 
    }, 
    function(result){
      var gst_rate = result;
      gst_rate = +(inc_gst)* (+(gst_rate)/100);
      var ex_gst = inc_gst - gst_rate;
      $("#price_ex_gst").val(ex_gst);
    });
  })
  
  $("#price_ex_gst").keyup(function(){
    var ex_gst = $("#price_ex_gst").val();
    $.post(baseurl+"works/fetch_gst_rate", 
    { 
    }, 
    function(result){
      var gst_rate = result;
      gst_rate = +(ex_gst)* (+(gst_rate)/100);
      var inc_gst = +(ex_gst) + +(gst_rate);
      $("#inc_gst").val(inc_gst);
    });
  });

  $("#save_contractor").click(function(){
    var date_entered = $("#contractor_date_entered").val();
    var result = $("#work_contructor_name").val();
    var comp_id = result.split("|");
    comp_id = comp_id[1];
    var  contact_person_id= $("#contact_person").val();
   
    var inc_gst = $("#inc_gst").val();
    var ex_gst = $("#price_ex_gst").val();
    
    $.post(baseurl+"works/insert_contractor", 
    { 
      work_id: work_id,
      date_added: date_entered,
      comp_id: comp_id,
      contact_person_id: contact_person_id,
      inc_gst: inc_gst,
      ex_gst: ex_gst
    }, 
    function(result){
      $("#work_contractors").html(result);
    });
  });

  window.selcontractor = function(a){
    work_contractor_id = a;
    $.post(baseurl+"works/display_work_contractor", 
    { 
      stat: 1,
      work_id: work_id,
      work_contractor_id: work_contractor_id
    }, 
    function(result){
      $("#work_contractors").html(result);
      $("#save_contractor").hide();
      $("#update_contractor").show();
      $("#delete_contractor").show();
    });
  }

  $("#update_contractor").click(function(){
    var date_entered = $("#contractor_date_entered").val();
    var result = $("#work_contructor_name").val();
    var comp_id = result.split("|");
    comp_id = comp_id[1];
    var  contact_person_id= $("#contact_person").val();
   
    var inc_gst = $("#inc_gst").val();
    var ex_gst = $("#price_ex_gst").val();
    
    $.post(baseurl+"works/update_contractor", 
    { 
      work_contractor_id: work_contractor_id,
      work_id: work_id,
      date_added: date_entered,
      comp_id: comp_id,
      contact_person_id: contact_person_id,
      inc_gst: inc_gst,
      ex_gst: ex_gst
    }, 
    function(result){
      $("#work_contractors").html(result);
    });
  });
  $("#btn_work_con_del_conf_yes").click(function(){
    $.post(baseurl+"works/delete_contractor", 
    { 
      work_contractor_id: work_contractor_id,
      work_id: work_id,
    }, 
    function(result){
      $("#work_contractors").html(result);
      $('.modal').modal('hide');
    });
  });
  window.sel_work_con = function(a){
    selected_work_contractor_id = a;
  }
  $("#btn_select_subcontractor").click(function(){
    if(selected_work_contractor_id == 0){
      alert("You have not selected a contractor or the selected contractor is already set");
    }else{
      $.post(baseurl+"works/select_contractor", 
      { 
        selected_work_contractor_id: selected_work_contractor_id,
        work_id: work_id,
      }, 
      function(result){
        $("#work_contractors").html(result);
        //window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
        $.post(baseurl+"works/view_works_list", 
        { 
          //work_type: work_type,
          //work_con_sup_id: work_con_sup_id,
        }, 
        function(result){
          //window.open(baseurl+"projects/", '_self', true);
          //window.open(baseurl+"projects/view/"+proj_id, '_self', true);
          location.reload();
        })
      });
    }
  });
  $("#update_work_desc").hide();
  $("#edit_work_desc").hide();
  $("#edit_est_markups").hide();
  $("#edit_work_date").hide();
  $("#edit_considerations_list").hide();
  $('#update_work_notes').prop('readonly', true);
  $("#update_replyby_desc").prop('readonly',true);
  $("#chkdeltooffice").attr("disabled", true);
  $("#btn_edit_work_desc").click(function(){
    $("#lbl_work_desc").hide();
    $("#btn_edit_work_desc").hide();
    $("#edit_work_desc").show();
    var work_con_sup_id = $("#hid_work_con_sup_id").val();
    //$('#worktype option[value="' + work_con_sup_id +'"]').prop('selected', true);
  });
  $("#btn_save_work_desc").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    var work_type = $("#worktype").val();
    var arr = work_type.split('_');
    work_type = arr[0];
    var work_con_sup_id = arr[1];
    $.post(baseurl+"works/update_work", 
    { 
      work_id: work_id,
      proj_id: proj_id,
      work_type: work_type,
      work_con_sup_id: work_con_sup_id,
      update_stat: 5
    }, 
    function(result){
      window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
      $("#lbl_work_desc").show();
      $("#btn_edit_work_desc").show();
      $("#edit_work_desc").hide();
    });
  });

  $("#btn_work_del_conf_yes").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    $.post(baseurl+"works/update_work",
    {
      work_id: work_id,
      proj_id: proj_id,
      update_stat: 6
    },
    function(result){
      $.post(baseurl+"works/view_works_list", 
      { 
        //work_type: work_type,
        //work_con_sup_id: work_con_sup_id,
      }, 
      function(result){
        window.open(baseurl+"projects/view/"+proj_id, '_self', true);
      })
    });
   
    
  });

  $("#back_to_works").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    $.post(baseurl+"works/view_works_list", 
    { 
      work_id: work_id,
      proj_id: proj_id
      //work_type: work_type,
      //work_con_sup_id: work_con_sup_id,
      //update_stat: 5
    }, 
    function(result){
      window.open(baseurl+"projects/view/"+proj_id, '_self', true);
    })
  });
  $("#btn_edit_est_markup").click(function(){
    $("#est_markup").hide();
    $("#edit_est_markups").show();
    $("#btn_edit_est_markup").hide();
    $("#save_est_markup").show();
  });
  $("#save_est_markup").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    var work_estimate = $("#work_estimate").val();
    var work_markup = $("#work_markup").val();
    var work_quote_val = $("#work_quote_val").val();

    $.post(baseurl+"works/update_work", 
    { 
      work_id: work_id,
      proj_id: proj_id,
      work_estimate: work_estimate,
      work_markup: work_markup,
      work_quote_val: work_quote_val,
      update_stat: 1
    }, 
    function(result){
      window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
      $("#est_markup").show();
      $("#edit_est_markups").hide();;
      $("#btn_edit_est_markup").show();
      $("#save_est_markup").hide();
    });
  });
  $("#edit_notes").click(function(){
    $('#update_work_notes').prop('readonly', false);
    $("#edit_notes").hide();
    $("#save_notes").show();
  });
  $("#save_notes").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    var update_work_notes = $("#update_work_notes").val();

    $.post(baseurl+"works/update_work", 
    { 
      work_id: work_id,
      proj_id: proj_id,
      update_work_notes: update_work_notes,
      update_stat: 3
    }, 
    function(result){
      window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
      $('#work_notes').prop('readonly', true);
      $("#edit_notes").show();
      $("#save_notes").hide();
    });

  });
  $("#edit_work_dates").click(function(){
    $("#edit_work_dates").hide();
    $("#save_work_dates").show();
    $("#work_date").hide();
    $("#edit_work_date").show();
    $("#chkdeltooffice").attr("disabled", false);
    $("#update_replyby_desc").prop('readonly',false);
  });
  $("#save_work_dates").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    var work_replyby_date = $("#work_replyby_date").val();
    var update_replyby_desc = $("#update_replyby_desc").val();
    if($('#chkdeltooffice').is(':checked')){
      var chkdeltooffice = 1;
    }else{
      var chkdeltooffice = 0;
    }
  
    $.post(baseurl+"works/update_work", 
    { 
      work_id: work_id,
      proj_id: proj_id,
      work_replyby_date: work_replyby_date,
      update_replyby_desc: update_replyby_desc,
      chkdeltooffice: chkdeltooffice,
      update_stat: 2
    }, 
    function(result){
      window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
      $("#edit_work_dates").show();
      $("#save_work_dates").hide();
      $("#work_date").show();
      $("#edit_work_date").hide();
      $("#chkdeltooffice").attr("disabled", true);
      $("#update_replyby_desc").prop('readonly',true);
    });
       
  });
  $("#edit_considerations").click(function(){
    $("#edit_considerations").hide();
    $("#save_considerations").show();
    $("#considerations").hide();
    $("#edit_considerations_list").show();
  });
  $("#save_considerations").click(function(){
    var work_id = $("#work_id").val();
    var proj_id = $("#proj_id").val();
    if($('#chkcons_site_inspect').is(':checked')){
      var chkcons_site_inspect = 1;
    }else{
      var chkcons_site_inspect = 0;
    }
    if($('#chckcons_week_work').is(':checked')){
      var chckcons_week_work = 1;
    }else{
      var chckcons_week_work = 0;
    }
    if($('#chckcons_spcl_condition').is(':checked')){
      var chckcons_spcl_condition = 1;
    }else{
      var chckcons_spcl_condition = 0;
    }
    if($('#chckcons_weekend_work').is(':checked')){
      var chckcons_weekend_work = 1;
    }else{
      var chckcons_weekend_work = 0;
    }
    if($('#chckcons_addnl_visit').is(':checked')){
      var chckcons_addnl_visit = 1;
    }else{
      var chckcons_addnl_visit = 0;
    }
    if($('#chckcons_afterhrs_work').is(':checked')){
      var chckcons_afterhrs_work = 1;
    }else{
      var chckcons_afterhrs_work = 0;
    }
    if($('#chckcons_oprte_duringinstall').is(':checked')){
      var chckcons_oprte_duringinstall = 1;
    }else{
      var chckcons_oprte_duringinstall = 0;
    }
    if($('#chckcons_new_premises').is(':checked')){
      var chckcons_new_premises = 1;
    }else{
      var chckcons_new_premises = 0;
    }
    if($('#chckcons_free_access').is(':checked')){
      var chckcons_free_access = 1;
    }else{
      var chckcons_free_access = 0;
    }
    if($('#chckcons_others').is(':checked')){
      var chckcons_others = 1;
      var other_consideration = $("#other_consideration").val();
    }else{
      var chckcons_others = 0;
      var other_consideration = "";
    }
    $.post(baseurl+"works/update_work", 
    { 
      work_id: work_id,
      proj_id: proj_id,
      chkcons_site_inspect: chkcons_site_inspect,
      chckcons_week_work: chckcons_week_work,
      chckcons_spcl_condition: chckcons_spcl_condition,
      chckcons_weekend_work: chckcons_weekend_work,
      chckcons_addnl_visit: chckcons_addnl_visit,
      chckcons_afterhrs_work: chckcons_afterhrs_work,
      chckcons_oprte_duringinstall: chckcons_oprte_duringinstall,
      chckcons_new_premises: chckcons_new_premises,
      chckcons_free_access: chckcons_free_access,
      chckcons_others: chckcons_others,
      other_consideration: other_consideration,
      update_stat: 4
    }, 
    function(result){
      window.open(baseurl+"works/update_work_details/"+proj_id+"/"+work_id, '_self', true);
      $("#edit_considerations").show();
      $("#save_considerations").hide();
      $("#considerations").show();
      $("#edit_considerations_list").hide();
    });
    
  });
  $("#work_cont_po").click(function(){
    alert(work_id);
    window.open(baseurl+"works/work_contractor_po/"+work_id, '_self', false);
    
    return false;
  });
  /*$("#site_start").change(function(){
    alert("sfsd");
  });*/
 /* $("#frmcontractor").hide();
  $("#btnaddcontractor").click(function(){
    $("#txtselcompdate").val("");
    $("#selcontcompany").val("");
    $("#selattention").val("");
    $("#txtselcompnote").val("");
    $("#txtselcompincgst").val("");
    $("#txtselcompexgst").val("");
    $("#txtselcompremarks").val("");
    $("#addcontractor").show();
    $("#updatecontractor").hide();
    $("#removecontractor").hide();
  });
  $("#showaddworkmodal").click(function(){
    $("#works").val("");
    $("#work_estimate").val("");
    $("#work_sdate").val("");
    $("#work_markup").val("");
    $("#work_fdate").val("");
    $("#work_quote_val").val("");
    $("#work_replyby_date").val("");
    $("#replyby_desc").val("");
    $('#chkdeltooffice').attr('checked', false);
    $('#chkcons_site_inspect').attr('checked', false);
    $('#chckcons_week_work').attr('checked', false);
    $('#chckcons_spcl_condition').attr('checked', false);
    $('#chckcons_weekend_work').attr('checked', false);
    $('#chckcons_addnl_visit').attr('checked', false);
    $('#chckcons_afterhrs_work').attr('checked', false);
    $('#chckcons_oprte_duringinstall').attr('checked', false);
    $('#chckcons_new_premises').attr('checked', false);
    $('#chckcons_free_access').attr('checked', false);
    $("#other_consideration").val("");
    $("#work_notes").val("");
    $("#work_cpodate_req").val("");
    $("#work_cpo_date").val("");
    $("#addcontractor").show();
    $("#updatecontractor").hide();
    $("#removecontractor").hide();
  });
  window.contractor = function(){
    $("#frmcontractor").show();
    return false;
  }
  window.editwork = function(a){
    work_id = a;
    $.post(baseurl+"works/display_work_form", 
    { 
      work_id: a
    }, 
    function(result){
      $("#frm_add_works").html(result);
    });
    $("#addcontractor").hide();
    $("#updatecontractor").show();
    $("#removecontractor").show();
  }*/

  /*$("#attach").click(function(){
    alert("dsfsd");
  });*/

	// affix sidebar
	$('#sidebar').affix({offset : {top : 75}});
	var $body = $(document.body);
	var navHeight = $('.top-nav').outerHeight(true) + 10;
	$body.scrollspy({target : '#leftCol',offset : navHeight	});
	// affix sidebar	

	$('.popover-test').popover();
	$('.popover-form').popover();
	
	 
	
	$('.tooltip-test').tooltip();	
	$('.tooltip-enabled').tooltip();		
	
	$('#loading-example-btn').click(function(){
        var btn = $(this);
        btn.button('loading');
        setTimeout(function () {
            btn.button('reset');
            $(".alert").alert('close');
        }, 1000);
    });


  var base_mark_up = 0;
  $("#job_category").change(function(){
    var job_category = $(this).val();
    
    $('#project_markup').empty();
    $('.min_mark_up').empty();


    $.post(baseurl+"projects/fetch_mark_up_by",{ 
      job_cat: job_category
    },
    function(result){
      var mark_up = result.split("|");
      base_mark_up = mark_up[0];
      $('#project_markup').val(mark_up[0]);
      $('.min_mark_up').text(mark_up[1]);
    });

  });


  $('#project_markup').blur(function(){

    var project_markup = parseInt($(this).val()).toFixed(2);
    var min_mark_up = parseInt($('.min_mark_up').text());

    if(project_markup < min_mark_up){
      $(this).val(base_mark_up);
    }

    if($(this).val() == ''){
      $(this).val(base_mark_up);
    }
      //load_data_ajax($(this).val());
}); //this is working select callbak!



/*$('#work_markup').blur(function(){

    var work_markup = parseInt($(this).val()).toFixed(2);
    var min_mark_up = parseInt($('.min_mark_up').text());

    if(work_markup < min_mark_up){
      $(this).val(min_mark_up);
    }

    if($(this).val() == ''){
      $(this).val(min_mark_up);
    }


    var quote = +($("#work_estimate").val()) +  (+($("#work_estimate").val()) * (+($("#work_markup").val())/100));
    $("#work_quote_val").val(quote);


      //load_data_ajax($(this).val());
}); *///this is working select callbak!


    $(".select-focus").on("change", function(e) {
      
        var myVal = $(this).val();
        var controller_method = 'projects/set_jurisdiction';
        $('select.state-option-a').empty();
        var classLocation = 'select.state-option-a';
        ajax_data(myVal,controller_method,classLocation);


        $('select.state-option-b').empty();
        var classLocationB = 'select.state-option-b';
        ajax_data(myVal,controller_method,classLocationB);
      
      //load_data_ajax($(this).val());
    }); //this is working select callbak!


    $(".find_contact_person").on("change", function(e) {
      
        var myVal = $(this).val();
        var controller_method = 'projects/find_contact_person';

        $('select#contact_person').empty();
        var classLocation = 'select#contact_person';
        ajax_data(myVal,controller_method,classLocation);


      
      //load_data_ajax($(this).val());
    }); //this is working select callbak!



    $(".get_address_invoice").on("change", function(e) {
      
        var myVal = $(this).val();
        var controller_method = 'projects/find_contact_person';

        $('select#contact_person').empty();
        var classLocation = 'select#contact_person';
        ajax_data(myVal,controller_method,classLocation);



        $.ajax({
        'url' : 'projects/fetch_address_company_invoice',
        'type' : 'POST',
        'data' : {'ajax_var' : myVal },
        'success' : function(data){
          //var divLocation = $(classLocation);
          if(data){

             var address_raw = data.split("|");

             $('#unitlevel2').val(address_raw[0]);
             $('#number2').val(address_raw[1]);
             $('#street2').val(address_raw[2]);
             $('#pobox').val(address_raw[3]);

             var state_invoice_val = address_raw[4]+'|'+address_raw[5]+'|'+address_raw[6]+'|'+address_raw[7];
             $('select#state_b').val(state_invoice_val);
             $('.state-option-b span.select2-chosen').text(address_raw[5]);

             var suburb_invoice_upper = address_raw[8].toUpperCase();

             var state_invoice_val = suburb_invoice_upper+'|'+address_raw[5]+'|'+address_raw[6];

             $('select#suburb_b').append('<option selected value="'+state_invoice_val+'">'+address_raw[8]+'</option>');
             $('select#suburb_b').val(state_invoice_val);
             $('.suburb-option-b span.select2-chosen').text(address_raw[8]);


             $('select#postcode_b').append('<option selected value="'+address_raw[9]+'">'+address_raw[9]+'</option>');
             $('select#postcode_b').val(address_raw[9]);
             $('.postcode-option-b span.select2-chosen').text(address_raw[9]);

          }
        }
      });
      
      //load_data_ajax($(this).val());
    }); //this is working select callbak!



    $('select#job_type').on("change", function(e) {
      
        var myVal = $(this).val();

        if(myVal == 'Shopping Center'){
          $('.site_address').hide();
          $('.shopping_center').show();
          $('.is_shopping_center').val(1);


        }else{
          $('.site_address').show();
          $('.shopping_center').hide();
          $('.is_shopping_center').val(0);

        }
  
    });



    
    
    $("#unit_level").on("change", function(e) {
    	if ($('.sameToPost').is(':checked')) {
   			//alert($(this).val());
	    	$("#unitlevel2").val($(this).val());
    	}
   		//load_data_ajax($(this).val());
   	}); //this is working select callbak!   	
   	
    $("#number").on("change", function(e) {
    	if ($('.sameToPost').is(':checked')) {
	    	$("#number2").val($(this).val());
    	}   		
   	});
   	
    $("#street").on("change", function(e) {
    	if ($('.sameToPost').is(':checked')) {
	    	$("#street2").val($(this).val());
    	}   		
   	});

   	$('#state_a').on("change", function(e) {

   		//alert($(this).val());

	 	if ($('.sameToPost').is(':checked')) {

	     	var setValRaw = $(this).val().split("|");
	        var optionText = setValRaw[1];

	    	$('#state_b').val( $(this).val() );
	        $('.state-option-b span.select2-chosen').text(optionText);
    	}

  

	});

	$('#suburb_a').on("change", function(e) {

	    if ($('.sameToPost').is(':checked')) {
	     	var setValRaw = $(this).val().split("|");
	        var optionText = setValRaw[0];
	        var optionVal = $(this).val();

	        optionText = optionText.toLowerCase();
	        optionText = optionText.replace(/\b./g, function(m){ return m.toUpperCase(); });

	        $('#suburb_b').empty().append('<option selected="selected" value="'+optionVal+'">'+optionText+'</option>');
	        $('#suburb_b').val( $(this).val());
	        $('.suburb-option-b span.select2-chosen').text(optionText);
	      }
	      //$('.postcode-option-b').empty().append('<option value="">Choose a Postcode...</option>');	
	});



	$('.data-area').on("hover", function(e) {
		var this_button = $(this).attr('id');
		
	 	alert(this_button);
    });


    $("#edit_company_name").click(function(){
    	$(this).hide();
    	$("#save_company_name").show();
    	$('.company_name').hide();
    	$('.company_name_data').show();
      $('#delete_company').show();
      $('#delete_focus').show();
      
    });

    $("#save_company_name").click(function(){
    	$(this).hide();
    	$("#edit_company_name").show();
    	$('.company_name').show();
      $('#delete_company').hide();
      $('#delete_focus').hide();
    	$('.company_name_data').hide();
    	var comp_name = $('#company_name_data').val();
    	$('.company_name').empty().text(comp_name);
    });

    $("#edit_physical_address").click(function(){
    	$(this).hide();
    	$("#save_physical_address").show();
    	$('.physical_address_group').hide();
    	$('.physical_address_group_data').show();
    });

    $("#save_physical_address").click(function(){
    	$(this).hide();
    	$("#edit_physical_address").show();
    	$('.physical_address_group').show();
    	$('.physical_address_group_data').hide();
    });

    $("#edit_postal_address").click(function(){
    	$(this).hide();
    	$("#save_postal_address").show();
    	$('.postal_address_group').hide();
    	$('.postal_address_group_data').show();
    });

    $("#save_postal_address").click(function(){
    	$(this).hide();
    	$("#edit_postal_address").show();
    	$('.postal_address_group').show();
    	$('.postal_address_group_data').hide();
    });

    $("#edit_bank_details").click(function(){
    	$(this).hide();
    	$("#save_bank_details").show();
    	$('.bank_details_group').hide();
    	$('.bank_details_group_data').show();
    });

    $("#save_bank_details").click(function(){
    	$(this).hide();
    	$("#edit_bank_details").show();
    	$('.bank_details_group').show();
    	$('.bank_details_group_data').hide();

    	var bank_name = $('#bank-name').val();
    	var account_name = $('#account-name').val();
    	var account_number = $('#account-number').val();
    	var bsb_number = $('#bsb-number').val();

    	$('span.data-bank-name').empty().text(bank_name);
    	$('span.data-account-name').empty().text(account_name);
    	$('span.data-account-number').empty().text(account_number);
    	$('span.data-bsb-number').empty().text(bsb_number);
    });

    $("#edit_more_details").click(function(){
    	$(this).hide();
    	$("#save_more_details").show();
    	$('.more_details_group').hide();
    	$('.more_details_group_data').show();
    });

    $("#save_more_details").click(function(){
    	$(this).hide();
    	$("#edit_more_details").show();
    	$('.more_details_group').show();
    	$('.more_details_group_data').hide();
    });

    $("#edit_comment_details").click(function(){
    	$(this).hide();
    	$("#save_comment_details").show();
    	$('.comments-data').hide();
    	$('.comments').show();
    });

    $("#save_comment_details").click(function(){
    	$(this).hide();
    	$("#edit_comment_details").show();
    	$('.comments-data').show();
    	$('.comments').hide();

    	$('.comments-data').empty().text($('.comments').val());

    });


    $("#edit_primary_contact").click(function(){
    	$(this).hide();
    	$("#save_primary_contact").show();
    	$('.primary-contact-group').hide();
    	$('.primary-contact-group-data').show();
    });

    $("#save_primary_contact").click(function(){
    	$(this).hide();
    	$("#edit_primary_contact").show();
      $('.primary-contact-group').show();
      $('.primary-contact-group-data').hide();
    });

    $(".edit_other_contact").click(function(){
      $(this).hide();
      var target = $(this).attr('id').substring(19);
      $('#save_other_contact_'+target).show();
      $('#delete_other_contact_'+target).show();
      $('.other-contact-group_'+target).hide();
      $('.other-contact-group-other_data_'+target).show();
    });

    $(".save_other_contact").click(function(){
      $(this).hide();
      var target = $(this).attr('id').substring(19);
      $('#delete_other_contact_'+target).hide();
      $('#edit_other_contact_'+target).show();
      $('.other-contact-group_'+target).show();
      $('.other-contact-group-other_data_'+target).hide();
    });

    $("#add_new_contact").click(function(){
      $(this).hide();
      $('#add_save_contact').show();
      $('#cancel_contact').show();
      $('.new_contact_area').show();
      $('#other_first_name').focus();
    });


    $("#cancel_contact").click(function(){
      $("#add_new_contact").show();
      $('#add_save_contact').hide();
      $('#cancel_contact').hide();

      $('.new_contact_area .form-control').each(function(){
        $(this).val('');
      });

      $('.new_contact_area').hide();
    });

    $("#edit_other_details").click(function(){
      $(this).hide();
      $('#save_other_details').show();
      $('.more_details_group').hide();
      $('.more_details_group_data').show();
    });

    $("#save_other_details").click(function(){
      $(this).hide();
      $('#edit_other_details').show();
      $('.more_details_group').show();
      $('.more_details_group_data').hide();
    });


    $("#edit_contact_details").click(function(){
      $(this).hide();
      $('#save_contact_details').show();
      $('.contact_details_group').hide();
      $('.contact_details_group_data').show();
    });

    $("#save_contact_details").click(function(){
      $(this).hide();
      $('#edit_contact_details').show();
      $('.contact_details_group').show();
      $('.contact_details_group_data').hide();
    });





    







/* data tables op */
 
$('#worksTable tbody').on( 'click', 'span.remove-row', function () {
    var row = $(this).parent().parent();
    //var rowNode = row.node();
    row.remove();
});

$('#worksTable tbody').on( 'click', 'span.set-comp', function () {
   // alert('set-comp'); 
});
 
$('#worksTable tbody').on( 'click', 'span.add-attach', function () {
    //alert('add-attach'); 
});


 
$('#variationTable tbody').on( 'click', 'span.remove-row', function () {
    var row = $(this).parent().parent();
    //var rowNode = row.node();
    row.remove();
});
 
$('#variationTable tbody').on( 'click', 'span.set-comp', function () {
    //alert('set-comp'); 
});
 
$('#variationTable tbody').on( 'click', 'span.remove-comp', function () {
    //alert('remove-comp'); 
});
 
$('#variationTable tbody').on( 'click', 'span.add-attach', function () {
   // alert('add-attach'); 
});

/* data tables op */







    














    











	$('#type').on("change", function(e) {
		var this_val = $(this).val();		
	 	if ( this_val == 'Client|1' ) {
      		$('.bank_account').hide();
    	}else{
      		$('.bank_account').show();
    	}
	});	

	$('#postcode_a').on("change", function(e) {
	 	if ($('.sameToPost').is(':checked')) {
      		var optionVal = $(this).val();
      		$('#postcode_b').empty().append('<option value="'+optionVal+'">'+optionVal+'</option>');
	    	$('#postcode_b').val( $(this).val() );
	        $('.postcode-option-b span.select2-chosen').text($(this).val());
    	}
	});

   	$('.job-date-set').on("change", function(e) {
	 	if($(this).val() == ''){
	 		$('.is_wip').prop('checked', false);
	 	}else{
	 		$('.is_wip').prop('checked', true);
	 	}
	 });

   	$(".select-arr-tbl").on("change", function(e) { 
	 	//alert($(this).val());
	 	if($(this).val() == 'asc'){
	 		//table.fnSort( [ [4,'asc'] ] ); 		
	 		table.fnFilter('Unset','4');
	 	}else if($(this).val() == 'desc'){
	 		//table.fnSort( [ [4,'desc'] ] );
	 		table.fnFilter('-','4');
	 	}else{
	 		table.fnFilter('','');
	 	}
	 });



   	$("#abn").focusout(function(){
	 	if($(this).val() == ''){
	 		//$('.is_wip').prop('checked', false);
	 		$("#acn").val('');
	 	}else{
	 		var abn = $(this).val().replace(/[^\d]/g, "");

	 		var new_abn_val = abn.substring( -2,2)+' '+abn.substring( 2,5)+' '+abn.substring( 5,8)+' '+abn.substring( 8,11);
	 		$(this).val(new_abn_val);

	 		var acn_val = abn.substring( 2,5)+' '+abn.substring( 5,8)+' '+abn.substring( 8,11);

	 		$("#acn").val(acn_val);
	 	}
	 });


   	$( ".mobile_number_assign" ).keyup(function() {

   		keyup_counter++;
   		var abn = $(".mobile_number_assign").val();

   		if(keyup_counter%3==0){
   			$(".mobile_number_assign").val(abn+' ');
   		}
   	});

   	$("#street2").on("change", function(e) {
   		
   		if($(this).val() !='' ){
   			$("input#pobox").parent().addClass('disabled-input');
   			$('div.state-option-b a.select2-choice').focus();
   		}else{
   			$("input#pobox").parent().removeClass('disabled-input');
   		}
   	});
  
   	$("#pobox").on("change", function(e) {
    	if($(this).val() !='' ){
    		$("input#street2").parent().addClass('disabled-input');
    		$('div.state-option-b a.select2-choice').focus();
    	}else{
    		$("input#street2").parent().removeClass('disabled-input');
    	}
   	});

    $(".sameToPost").click(function(){    	
		if ($(this).is(':checked')) {

			$("#unitlevel2").val('');
	    	$("#number2").val('');
	    	$("#street2").val('');

	    	$("#state_b").val('');	    	
	        $('.state-option-b span.select2-chosen').text('Choose a State...');

	    	$("#suburb_b").val('');
	        $('.suburb-option-b span.select2-chosen').text('Choose a Suburb...');

	    	$("#postcode_b").val('');
	        $('.postcode-option-b span.select2-chosen').text('Choose a Postcode...');

	    	$("#state_b").val($("#state_a").val());
	    	var stateValRaw = $("#state_a").val().split("|");
	        var stateText = stateValRaw[1];
	        $('.state-option-b span.select2-chosen').text(stateText);

			$("#suburb_b").empty();
			var setValRaw = $('#suburb_a').val().split("|");
	        var optionText = setValRaw[0];
	        var optionVal = $("#suburb_a").val();

	        optionText = optionText.toLowerCase();
	        optionText = optionText.replace(/\b./g, function(m){ return m.toUpperCase(); });

	        $('#suburb_b').empty().append('<option value="'+optionVal+'">'+optionText+'</option>');
	        $('#suburb_b').val( $('#suburb_a').val());

	        $('.suburb-option-b span.select2-chosen').text(optionText);

	        $("input#pobox").val('');


   	

	    	$("#postcode_b").empty();
	    	var postcode_aVAl = $("#postcode_a").val();
	    	var child = '<option value="'+postcode_aVAl+'">'+postcode_aVAl+'</option>';
	    	$("#postcode_b").append(child);
	    	$("#postcode_b").val($("#postcode_a").val());
	        $('.postcode-option-b span.select2-chosen').text(postcode_aVAl);

	    	$("#unitlevel2").val($("#unit_level").val());
	    	$("#number2").val($("#number").val());
	    	$("#street2").val($("#street").val());

          	$("input#pobox").parent().addClass('disabled-input');
	    	$("input#unitlevel2").parent().addClass('disabled-input');
	    	$("input#number2").parent().addClass('disabled-input');
	    	$("input#street2").parent().addClass('disabled-input');

          	$('div.state-option-b').addClass('disabled-input');	
          	$('div.suburb-option-b').addClass('disabled-input');	
          	$('div.postcode-option-b').addClass('disabled-input');

	    	
		} else {
			//$(this).prop('checked',true);
			//alert("not checked");
	    	$("#unitlevel2").val('');
	    	$("#number2").val('');
	    	$("#street2").val('');

	    	$("#state_b").val('');	    	
	        $('.state-option-b span.select2-chosen').text('Choose a State...');

	    	$("#suburb_b").val('');
	        $('.suburb-option-b span.select2-chosen').text('Choose a Suburb...');

	    	$("#postcode_b").val('');
	        $('.postcode-option-b span.select2-chosen').text('Choose a Postcode...');
	
          	$('div.state-option-b').removeClass('disabled-input');	
          	$('div.suburb-option-b').removeClass('disabled-input');	
          	$('div.postcode-option-b').removeClass('disabled-input');

          	$("#unitlevel2").parent().removeClass('disabled-input');
	    	$("#number2").parent().removeClass('disabled-input');
	    	$("#street2").parent().removeClass('disabled-input');
          	$('#pobox').parent().removeClass('disabled-input');
		}    	
    });
    
    $(".chosen").select2({
		allowClear : true
	}).removeClass('form-control');


    $(".chosen-multi").select2({
    	placeholder: "Select...",
		allowClear : true
	}).removeClass('form-control');

    
    $(".set-contact").on("click", function () {
    	var contactType = $("#contact-types").val();
    	var contactPersonItem = $("#contact-person-item").val();


    	if(contactType && contactPersonItem){
    		//alert(contactType+' - '+contactPersonItem+' - '+contactSetCount);



    		var setValRawContactPerson = $("#contact-person-item").val().split("|");

    		$('.contact-sets-area').append('<input type="hidden" name="contact-person-'+contactSetCount+'" class="contact-item-'+contactSetCount+'"  value="'+contactType+'|'+contactPersonItem+'" >');
    		$('.contact-sets-area').append('<div onCLick="removeElem(\'contact-item-'+contactSetCount+'\')" class="contact-item-element" id="contact-item-'+contactSetCount+'">'+contactType+' - '+setValRawContactPerson[0]+' '+setValRawContactPerson[1] +'</div>');

    		

    		if($("#assigned-contact-impt").val() == ''){
    			$("#assigned-contact-impt").val(contactSetCount);
    		}else{
    			$("#assigned-contact-impt").val($("#assigned-contact-impt").val()+','+contactSetCount);
    		}


    		contactSetCount++;
    		
    	}else{
    		alert("Please Set Contact Type and Contact Person.");
    	}



    	$('#s2id_contact-person-item span#select2-chosen-10').text('Choose a Contact Person...');
    	$("#contact-types").val('');
    	$("select#contact-person-item").val(null);
    });

	$("input#company_name").focus();

    



    
    $(".set-add-contact").on("click", function () {
    	var is_set_as_primary = 0;

    		//alert(contactType+' - '+contactPersonItem+' - '+contactSetCount);
    		$('.add-contact-area').append('<div class="item-form item-form-'+contactSetAddCount+'" ><div class="clearfix"></div> <div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="contact_f_name_'+contactSetAddCount+'" class="col-sm-3 control-label">First Name*</label><div class="col-sm-9"><input type="text" class="form-control" id="contact_f_name_'+contactSetAddCount+'" placeholder="First Name" name="contact_f_name_'+contactSetAddCount+'" value=""></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="contact_l_name_'+contactSetAddCount+'" class="col-sm-3 control-label">Last Name*</label><div class="col-sm-9"><input type="text" class="form-control" id="contact_l_name_'+contactSetAddCount+'" placeholder="Last Name" name="contact_l_name_'+contactSetAddCount+'" value=""></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="gender_'+contactSetAddCount+'" class="col-sm-3 control-label">Gender*</label><div class="col-sm-9"><select name="contact_gender_'+contactSetAddCount+'"  class="form-control gender_add_set" id="gender_'+contactSetAddCount+'"><option value="Male">Male</option><option value="Female">Female</option></select></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="contact_email_'+contactSetAddCount+'" class="col-sm-3 control-label">Email</label><div class="col-sm-9"><input type="email" class="form-control" id="contact_email_'+contactSetAddCount+'" placeholder="Email" name="contact_email_'+contactSetAddCount+'" value=""></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="contact_number_'+contactSetAddCount+'" class="col-sm-3 control-label">Office Contact</label><div class="col-sm-9"><div class="input-group"><span class="input-group-addon" id="area-code-text-'+contactSetAddCount+'"></span><input type="text" class="form-control contact_number_assign"  onchange="contact_number_assign(\'contact_number_'+contactSetAddCount+'\')" id="contact_number_'+contactSetAddCount+'" placeholder="Office Contact Number" name="contact_number_'+contactSetAddCount+'" value=""></div></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="mobile_number_'+contactSetAddCount+'" class="col-sm-3 control-label">Mobile</label><div class="col-sm-9"><input type="text" class="form-control mobile_number_assign mobile_number_assign"  onchange="mobile_number_assign(\'mobile_number_'+contactSetAddCount+'\')" id="mobile_number_'+contactSetAddCount+'" placeholder="Mobile Number" name="mobile_number_'+contactSetAddCount+'" value=""></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label class="col-sm-3 control-label" for="after_hours_'+contactSetAddCount+'">After Hours</label><div class="col-sm-9"><div class="input-group"><span class="input-group-addon" id="mobile-area-code-text-'+contactSetAddCount+'"></span><input type="text" value="" name="after_hours_'+contactSetAddCount+'" placeholder="After Hours Contact Number" onchange="contact_number_assign(\'after_hours_'+contactSetAddCount+'\')" id="after_hours_'+contactSetAddCount+'" class="form-control after_hours_assign"></div></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label for="contact_type_'+contactSetAddCount+'" class="col-sm-3 control-label">Contact Type</label><div class="col-sm-9"><select name="contact_type_'+contactSetAddCount+'" id="contact_type_'+contactSetAddCount+'" class="form-control"><option value="General">General</option><option value="Maintenance">Maintenance</option><option value="Accounts">Accounts</option><option value="Other">Other</option></select></div></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><label class="col-sm-3 control-label" for="set_as_primary_'+contactSetAddCount+'">Set as Primary</label><input type="checkbox" name="set_as_primary_'+contactSetAddCount+'" id="set_as_primary_'+contactSetAddCount+'" class="set_as_primary" onclick="contact_set_primary(\'set_as_primary_'+contactSetAddCount+'\')" style="margin-top: 10px; margin-left: 5px;"></div><div class="col-md-6 col-sm-6 col-xs-12 m-bottom-10 clearfix"><div class="btn btn-warning pull-right" id="remove-form-_'+contactSetAddCount+'" onClick="removeFormAdd(\'item-form-'+contactSetAddCount+'\')">Remove Form</div></div><div class="clearfix"></div><hr /></div>');
    		


    		if($("#add-contact-impt").val() == ''){
    			$("#add-contact-impt").val(contactSetAddCount);
    		}else{
    			$("#add-contact-impt").val($("#add-contact-impt").val()+','+contactSetAddCount);
    		}
    		$( "#contact_f_name_"+contactSetAddCount ).focus();


    		$("#area-code-text-"+contactSetAddCount).text($("#areacode").val());
    		$("#mobile-area-code-text-"+contactSetAddCount).text($("#areacode").val());


    		contactSetAddCount++;

    		$('input.set_as_primary').each(function(index, value){
    			if($(this).is(':checked')){ is_set_as_primary = 1; }    			
    		});


    		if(is_set_as_primary == 0){
    			$('input.set_as_primary:first').click();
    		}

    });


	$('.reset-form-data').click(function(){
		$("#assigned-contact-impt").val(null);
		$("#add-contact-impt").val(null);
		$('.add-contact-area').empty();
		$(".contact-sets-area").empty();
		contactSetCount = 1;
		contactSetAddCount = 1;
	});






    

	
	$('.edit-project').on('click', function(){
	    if($('.project-form .form-control').prop("readonly")){
			$(this).val('Cancel Edit');			
			$('.project-form .form-control').each(function(){
				$(this).attr("readonly",false);
			});
			$('.save-project').removeClass('hidden').attr("disabled",false);
			$('#suburb').attr("disabled",false);
			$('#suburb_a').attr("disabled",false);
			$('#suburb_b').attr("disabled",false);
			$('#postcode_a').attr("disabled",false);
		}else{
			$(this).val('Edit project');			
			$('.project-form .form-control').each(function(){
				$(this).attr("readonly",true);
			});
			$('.save-project').addClass('hidden').attr("disabled",true);
			$('#suburb').attr("disabled",true);
			$('#suburb_a').attr("disabled",true);
			$('#suburb_b').attr("disabled",true);
			$('#postcode_a').attr("disabled",true);
		}
		$('#project_date').attr("readonly",true);
		$('state_a').attr("readonly",true);	
		$('#areacode').attr("readonly",true);			
	});
	
	
	var setname = $('.select2-default').text();	
	//$(".chosen").select2("data", {id: "setname", text: setname}); hey!!!!!!!!!
	$('.edit-record').on('click', function(){
	    if($('.company-form .form-control').prop("readonly")){
			$('.company-form .form-control').attr("readonly",false);
			$('.company-form .btn-success').attr("readonly",false);
			$(this).val('Cancel Edit');
			$('.btn-success').show().prop('type', 'submit');
			$('#suburb_a').attr("disabled",false);
			$('#suburb_b').attr("disabled",false);
			$('#postcode_a').attr("disabled",false);
			$('#postcode_b').attr("disabled",false);
			$('#type').attr("disabled",false);		
			$('#activity').attr("disabled",false);	
			$('#parent').attr("disabled",false);	
			$(".chosen").select2("readonly", false, "data", {id: "setname", text: setname});
			$("#contactperson").attr("disabled",false);		
		}else{
			$('.company-form .form-control').attr("readonly",true);
			$(this).val('Edit Record');
			$('.company-form .btn-success').attr("readonly",true);
			$('.btn-success').hide().prop('type', 'button');	
			$('#suburb_a').attr("disabled",true);
			$('#suburb_b').attr("disabled",true);
			$('#postcode_a').attr("disabled",true);
			$('#postcode_b').attr("disabled",true);
			$('#type').attr("disabled",true);	
			$('#activity').attr("disabled",true);	
			$('#parent').attr("disabled",true);
			$(".chosen").select2("readonly", true, "data", {id: "setname", text: setname});
			$("#contactperson").attr("disabled",true);
		}
		$('.state').attr("readonly",true);
		$('.areacode').attr("readonly",true);		
	});
	
	$('#add_contact').on('hide.bs.modal', function (e) {
		$('#contactperson').not(':button, :submit, :reset, :hidden').val('').removeAttr('checked').removeAttr('selected');
		$('#contact_f_name').val('').parent().parent().removeClass('has-error');
		$('#contact_l_name').val('').parent().parent().removeClass('has-error');
		$('#contact_email').val('').parent().parent().removeClass('has-error');
		$('#contact_number').val('').parent().parent().removeClass('has-error');
		$('#contact_company').val('').parent().parent().removeClass('has-error');
		$('#select2-chosen-2').empty();
		$('#gender').val('').removeAttr('selected').parent().parent().removeClass('has-error');
	});
	
	$('.add-contact-submit').click(function(){
		var contactDetail = new Array();
		var errorFormSub = 0;
		contactDetail['contact_f_name'] =  $('#contact_f_name').val();
		contactDetail['contact_l_name'] = $('#contact_l_name').val();
		contactDetail['gender'] = $('#gender').val();
		contactDetail['contact_email'] = $('#contact_email').val();
		contactDetail['contact_number'] = $('#contact_number').val();
		//contactDetail['contact_company'] = $('#contact_company').val();		
		
		//alert($('#select2-chosen-2').text());			
		for (var key in contactDetail){
			if (contactDetail.hasOwnProperty(key)){
		  		//alert(contactDetail[key]);		  		
		  		if(contactDetail[key]==''){
		  			$('#'+key).parent().parent().addClass('has-error');
		  			errorFormSub = 1;
		  		}else{
		  			$('#'+key).parent().parent().removeClass('has-error');
		  		}
		  	}
		}
		
		if(errorFormSub == 0){
			$('#add_contact').modal('hide');
			$("select#contactperson").append('<option selected="selected" value="'+contactDetail['contact_f_name']+'|'+contactDetail['contact_l_name']+'">'+contactDetail['contact_f_name']+' '+contactDetail['contact_l_name']+'</option>');
    		
    		/*
    		var conName = contactDetail['contact_f_name']+' '+contactDetail['contact_l_name'];
    		$(".chosen").select2("data", {id: "setname", text: conName},{allowClear : true});*/
		}
	});
	/* */
	var controller = 'company';
	
	//load_data_ajax
	function load_data_ajax(contactDetails){
		//alert(contactDetails);
		var val = contactDetails.split("|");
    	$.ajax({
        	'url' : base_url + controller + '/add_contact',
            'type' : 'POST', //the way you want to send data to your URL
            'data' : {'first_name' : val[0],'last_name':val[1],'gender':val[2],'email':val[3],'contact_number':val[4],'company':val[5] },
            'success' : function(data){ //probably this request will return anything, it'll be put in var "data"
            	if(data){
                	//var valuesData = data.split("|");
                	//alert(data);
                	//state.disabled=false;
                	//state.val(valuesData[1]);
                	//state.readonly=true;
                	
                	//areacode.val(valuesData[2]);
                	$('.pop-test').html(data);
            	}
        	}
    	});
	}
	/* */
    //$(".chosen").on("change", function(e) { alert($(this).val()); }); this is working select callbak!
    
 


   
 //$('#projectTable').table.column(1).search( val ? '^test$' : val, true, false ).draw();
   // table.column(1).data().unique().sort().each( function ( d, j ) { select.append( '<option value="'+d+'">'+d+'</option>' ); } );
   

//dynamic_value_ajax
	function dynamic_value(setVal,postVal,controlerFunc,classLocation){
    	$.ajax({
        	'url' : base_url+controlerFunc,
            'type' : 'POST',
            'data' : {postVal : setVal },
            'success' : function(data){
            	var divLocation = $(classLocation);
                if(data){
                	divLocation.html(data);
            	}
        	}
    	});
   }
   //dynamic_value_ajax

    $("#work-type").on("change", function(e) {
    	var valuesData = $(this).val().split("|");
    	var setVal = valuesData[2];
      dynamic_value(setVal,'postVal','projects/sub_job_cat_list','.work-desc');
    });


	
	$('.remove-job').click(function(){
		var removeId = $(this).attr('id');
		dynamic_value(removeId,'postVal','projects/removeWork','.ignore'); //note the .ignore means nothing
		$(this).parent().parent().remove();
	});

	$('.set-company').click(function(){
		var typeId = $(this).attr('id');
		//alert(typeId);
		dynamic_value(typeId,'postVal','company/select_contractor_supplier','.select-comp-type'); 
	});

	$('.sub-nav-bttn').click(function(){
		var nav_trgt = $(this).attr('id');

		$('.project-details-update').hide();
		$('.quotation-view').hide();
		$('.'+nav_trgt).show();
	});


	$("#time-half").on("change", function(e){

		var timeHalf = parseInt($(this).val());
		var doubleTime = parseInt($('#time-half').val());
		var standardLabour = parseInt(100 - (timeHalf + doubleTime));

		if(standardLabour < 1 || standardLabour > 100 ){
			$(this).parent().parent().addClass('has-error');
			$(this).parent().parent().addClass('has-feedback');

			alert('Please reduce the values of Time & Half Labour');
		}else{
			$('#standard-labour').val(standardLabour);
			$(this).parent().parent().removeClass('has-error');
			$(this).parent().parent().removeClass('has-feedback');
		}

	});


	$("#company_name").on("change", function(e){
		$("#account-name").val($(this).val());
	});

		$("#double-time").on("change", function(e){

		var doubleTime = $(this).val();
		var timeHalf = $('#time-half').val();
		var standardLabour = 100 - (+timeHalf + +doubleTime);

		//alert(gstRate+' '+installationLabour+' '+standardLabour+ ' '+checkSum);

		if(standardLabour < 1 || standardLabour > 100 ){
			$(this).parent().parent().addClass('has-error');
			$(this).parent().parent().addClass('has-feedback');
			alert('Please reduce the values of Installation Labour');
		}else{
			$('#standard-labour').val(standardLabour);
			$(this).parent().parent().removeClass('has-error');
			$(this).parent().parent().removeClass('has-feedback');
		}

	});

    $('#work_notes').keyup(function() {
      var lines_left = 10;
      var vals = $("textarea").val().split(/\r\n|\r|\n/)
      .filter($.trim)
      .map($.trim);

      lines_left = lines_left - vals.length;

      $(".lines_left").text(lines_left);
    });


 $('.datepicker').datepicker()
});


function removeElem(value){
	$("."+value).remove();
	$("#"+value).remove();


	var assignedContactImpt = $("#assigned-contact-impt").val();

	var newAssignVal = assignedContactImpt.replace(value.substring(13),'');
	$("#assigned-contact-impt").val(newAssignVal);


}

function contact_set_primary(value){
	//$('.set_as_primary')
	$('.set_as_primary').prop('checked', false);	
	$('#'+value).prop('checked', true);
}


function removeFormAdd(value){
	$('.'+value).remove();

	var assignedContactImpt = $("#add-contact-impt").val();

	var newAssignVal = assignedContactImpt.replace(value.substring(10),'');
	$("#add-contact-impt").val(newAssignVal);	
}

function contact_number_assign(here){
	var curVal = $("#"+here).val().replace(/\s/g, '');

   	var valhere = curVal.substring( 0,4)+' '+curVal.substring(4,8)+' '+curVal.substring(8,12)+' '+curVal.substring(12,16)+' '+curVal.substring(16,20);
	$("#"+here).val(valhere);
}

function mobile_number_assign(here){
	var curVal = $("#"+here).val().replace(/\s/g, '');
	var valhere = curVal.substring( 0,4)+' '+curVal.substring(4,7)+' '+curVal.substring(7,10)+' '+curVal.substring(10,13)+' '+curVal.substring(13,16);
	$("#"+here).val(valhere);

}

function toTitleCase(str){
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}