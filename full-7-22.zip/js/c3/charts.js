// bar combination chart
var chart1 = c3.generate({
		bindto : '#chart1',
        data: {
          x: 'x',
          columns: [
          	['x', 'March', 'April', 'May', 'June', 'July','August'],
            ['Mike', 30, 20, 50, 40, 60, 50],
            ['James', 200, 130, 90, 240, 130, 220],
            ['data3', 300, 200, 160, 400, 250, 250],
            ['Target', 200, 130, 90, 240, 130, 220],
            ['data5', 130, 120, 150, 140, 160, 150],
            ['Invoice', 90, 70, 20, 50, 60, 120],
          ],
          types: {
            Mike: 'bar',
            James: 'bar',
            data3: 'spline',
            Target: 'line',
            data5: 'bar',
            Invoice: 'area'
          },
          /*groups: [
            ['Mike','James']
          ]*/
        },
        axis: {
          x: {
            type: 'categorized',label: {
              text: 'X Axis Label',
              position: 'outer-right'
            }
          },           
          y: {
            label: {
              text: 'Y Axis Label',
              position: 'outer-middle'
            }
          }
        }
    });
// bar combination chart
       
       // donut chart
      var chart2 = c3.generate({
			bindto : '#chart2',
        data: {        
          columns: [
            ["Installation Cost", 32],
            ["Total Project Estimate", 53],
            ["Other Cost", 15],
          ],
          type : 'donut',
        },
        
        
		donut: { title: "Manila Nike Store",
			onmouseover: function(d, i) {
				console.log(d, i);
			}, onmouseout: function (d, i) {
				console.log(d, i);
			}, onclick: function (d, i) {
				console.log(d, i);
			},
		}
      });
     // donut chart
     

       // donut company chart
       /*
      var company = c3.generate({
			bindto : '#company',
        data: {        
          columns: [
            ["Clients", 42],
            ["Suppliers", 27],
            ["Contractors", 31],
          ],
          type : 'donut',
        },
        
        
		donut: { title: "Total Companies: 135",
			onmouseover: function(d, i) {
				console.log(d, i);
			}, onmouseout: function (d, i) {
				console.log(d, i);
			}, onclick: function (d, i) {
				console.log(d, i);
			},
		}
      });
      */
     // donut company chart