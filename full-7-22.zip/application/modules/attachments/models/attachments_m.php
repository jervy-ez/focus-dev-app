<?php

class Attachments_m extends CI_Model{
	public function display_selected_project_attachments($projid){
		$query = $this->db->query("SELECT * FROM project_attachments a LEFT JOIN attachment_type b on a.attachment_type_id = b.attachment_type_id where project_id = '$projid'");
		return $query;
	}
	public function display_selected_attachment($project_attachments_id){
		$query = $this->db->query("SELECT * FROM project_attachments a LEFT JOIN attachment_type b on a.attachment_type_id = b.attachment_type_id where project_attachments_id = '$project_attachments_id'");
		return $query;
	}
	public function display_all_project_attachments(){
		$query = $this->db->query("SELECT * FROM project_attachments a LEFT JOIN attachment_type b on a.attachment_type_id = b.attachment_type_id");
		return $query;
	}
	public function display_all_attachment_type(){
		$query = $this->db->query("SELECT * FROM  attachment_type");
		return $query;
	}
	public function insert_attachment_type($attachment_type){
		$query = $this->db->query("INSERT INTO attachment_type (attachment_type) values('$attachment_type')");
		return $query;
	}

	public function update_attachment_type($attachment_type,$project_attachment_id){
		$query = $this->db->query("UPDATE `attachment_type` SET `attachment_type` = '$attachment_type' WHERE `attachment_type_id` = '$project_attachment_id'");
		return $query;
	}

	public function delete_attachment_type($project_attachment_id){
		$query = $this->db->query("DELETE FROM `attachment_type` WHERE `attachment_type_id` = '$project_attachment_id'");
		return $query;
	}

	public function insert_proj_attachments($proj_id,$attachment_type,$attachment_url){
		$attachment_date = date('d/m/Y');
		$this->db->query("INSERT INTO `project_attachments` (`project_id`, `attachment_type_id`, `project_attachments_url`, `project_attachements_date`) 
			VALUES ('$proj_id', '$attachment_type', '$attachment_url', '$attachment_date')");
	}

	public function update_project_attachment_type($attachment_type,$project_attachment_id){
		$query = $this->db->query("UPDATE `project_attachments` SET `attachment_type_id` = '$attachment_type' WHERE `project_attachments_id` = '$project_attachment_id'");
		return $query;
	}

	public function update_project_attachment_status($proj_attachment_status,$project_attachment_id){
		$query = $this->db->query("UPDATE `project_attachments` SET `is_selected` = '$proj_attachment_status' WHERE `project_attachments_id` = '$project_attachment_id'");
		return $query;
	}
}

?>