<?php

class Variation_m extends CI_Model{
	public function display_all_variation($projid){
		$query = $this->db->query("select * from variation where project_id = '$projid' order by variation_name");
		return $query;
	}

	public function display_selected_variation($variation_id){
		$query = $this->db->query("select * from variation where variation_id = '$variation_id'");
		return $query;
	}

	public function insert_variation($proj_id,$var_name,$site_hours,$is_double_time,$labor_cost,$var_credit,$variation_total,$var_mark_up,$var_acceptance_date,$var_notes){
		$var_date = date('d/m/Y');
		$query = $this->db->query("insert into variation (project_id,variation_name,variation_date,install_time_hrs,is_double_time,labor_cost,variation_credit,variation_cost,variation_total,variation_markup,acceptance_date,variation_notes) 
									values('$proj_id','$var_name','$var_date','$site_hours','$is_double_time','$labor_cost','$var_credit',0,'$variation_total','$var_mark_up','$var_acceptance_date','$var_notes')");
	}

	public function update_variation($proj_id,$var_name,$site_hours,$is_double_time,$labor_cost,$var_credit,$variation_total,$var_mark_up,$var_acceptance_date,$variation_id,$var_notes){
		$query = $this->db->query("update variation set project_id = '$proj_id' ,variation_name = '$var_name',install_time_hrs = '$site_hours',is_double_time = '$is_double_time',labor_cost = '$labor_cost',variation_credit = '$var_credit',variation_total = '$variation_total',variation_markup = '$var_mark_up',acceptance_date = '$var_acceptance_date', variation_notes = '$var_notes' where variation_id = '$variation_id'");
	}

	public function delete_variation($variation_id){
		$this->db->query("delete from variation where variation_id = '$variation_id'");
		$this->db->query("delete from works where variation_id = '$variation_id'");
	}

	public function update_variation_cost($variation_id,$cost){
		$query = $this->db->query("select * from variation where variation_id = '$variation_id'");
		foreach ($query->result_array() as $row){
			$labor_cost = $row['labor_cost'];
			$variation_credit = $row['variation_credit'];
		}
		$variation_total = ($labor_cost-$variation_credit) + $cost;
		$this->db->query("update variation set variation_cost = '$cost', variation_total = '$variation_total' where variation_id = '$variation_id'");	
	}

	public function fetch_variation_total($projid){
		$total_accepted = 0;
		$total_unaccepted = 0;
		$query = $this->db->query("select * from variation where project_id = '$projid' and acceptance_date = ''");

		foreach ($query->result_array() as $row){
			$total_unaccepted = $total_unaccepted + $row['variation_total'];
		}

		$query = $this->db->query("select * from variation where project_id = '$projid' and acceptance_date != ''");

		foreach ($query->result_array() as $row){
			$total_accepted = $total_accepted + $row['variation_total'];
		}

		$this->db->query("update project_cost_total set variation_total = '$total_accepted' where  project_id = '$projid'");
		
		return $total_accepted."|".$total_unaccepted;
	}
}