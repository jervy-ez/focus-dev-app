<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Variation extends MY_Controller{
	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');	
		$this->load->module('users');
		$this->load->module('company');
		$this->load->module('works');
		$this->load->model('works_m');
		$this->load->model('variation_m');
		$this->load->module('attachments');
		$this->load->module('send_emails');
		$this->load->model('send_emails_m');
		$this->load->model('invoice_m');
		//if($this->session->userdata('is_admin') == 1 ):		
			$this->load->module('admin');
		 	$this->load->model('admin_m');
		//endif;
		$this->load->module('projects');

		$this->load->helper(array('form', 'url','html'));
		//$this->load->model('project_m');
	}
	function index(){
	}
	
	function variations_view(){
		$project_id = $this->uri->segment(3);

		$q_proj = $this->projects_m->fetch_project_details($project_id);
		if($q_proj->num_rows > 0){
			$data = array_shift($q_proj->result_array());
			$projid = $data['project_id'];
		}else{
			$data['error'] = 'Unable to locate record';
		}

		$proj_q = $this->projects_m->select_particular_project($project_id);
		foreach ($proj_q->result_array() as $row){
			$data['job_date'] = $row['job_date'];
		}

		$data['projid'] = $projid;
		$data['screen'] = "Variation";
		$this->load->view('variation_v',$data);
	}

	public function variation_list(){
		$proj_id = $_POST['proj_id'];
		$data['var_q'] = $this->variation_m->display_all_variation($proj_id);
		$this->load->view('proj_variation_list', $data);
	}

	public function variation_labor_cost($proj_id,$site_hours,$is_double_time,$variation_markup){
		$proj_q = $this->projects_m->fetch_project_details($proj_id);
		foreach ($proj_q->result_array() as $row){
			$defaults_id = $row['defaults_id'];
		}

		$defaults_q = $this->admin_m->latest_system_default($defaults_id);
		foreach ($defaults_q->result_array() as $row){
			$site_cost_id = $row['site_cost_id'];
			$admin_default_id = $row['admin_default_id'];
		}

		$site_costs_q = $this->admin_m->fetch_site_costs($site_cost_id);
		foreach ($site_costs_q->result_array() as $row){
			$total_double_time = $row['total_double_time'];
			$total_amalgamated_rate = $row['total_amalgamated_rate'];
		}
		
		$admin_default_q = $this->admin_m->fetch_admin_defaults($admin_default_id);
		foreach ($admin_default_q->result_array() as $row){
			$installation_labour_mark_up = $row['installation_labour_mark_up'];
		}

		if($is_double_time == 0){
			$site_hour_value = $site_hours * $total_amalgamated_rate;
		}else{
			$site_hour_value = $site_hours * $total_double_time;
		}

		$labour_markup = $site_hour_value+($site_hour_value*($installation_labour_mark_up/100));

		$site_labour_total = $labour_markup+($labour_markup*($variation_markup/100));
		return $site_labour_total;
	} 

	public function get_proj_markup(){
		$var_proj_id = $_POST['proj_id'];
		$proj_q = $this->projects_m->fetch_project_details($var_proj_id);
		foreach ($proj_q->result_array() as $row){
			$mark_up = $row['markup'];
		}
		echo $mark_up;
	}
	public function add_variation(){
		$var_proj_id = $_POST['proj_id'];
		$var_name = $_POST['var_name'];
		$var_site_hrs = $_POST['var_site_hrs'];
		$var_is_double_time = $_POST['var_is_double_time'];
		$var_credit = $_POST['var_credit'];
		$var_markup = $_POST['var_markup'];
		$var_acceptance_date = $_POST['var_acceptance_date'];
		$var_notes = $_POST['var_notes'];


		$site_labour_total = $this->variation_labor_cost($var_proj_id,$var_site_hrs,$var_is_double_time,$var_markup);

		$variation_total = $site_labour_total - $var_credit;

		$this->variation_m->insert_variation($var_proj_id,$var_name,$var_site_hrs,$var_is_double_time,$site_labour_total,$var_credit,$variation_total,$var_markup,$var_acceptance_date,$var_notes);

		$data['var_q'] = $this->variation_m->display_all_variation($var_proj_id);
		$this->load->view('proj_variation_list', $data);
	}

	public function display_variation(){
		$variation_id = $_POST['variation_id'];
		$var_q = $this->variation_m->display_selected_variation($variation_id);
		foreach ($var_q->result_array() as $row){
			$proj_id = $row['project_id'];
			$variation_name = $row['variation_name'];
			$install_time_hrs = $row['install_time_hrs'];
			$is_double_time = $row['is_double_time'];
			$variation_credit = $row['variation_credit'];
			$variation_markup = $row['variation_markup'];
			$acceptance_date = $row['acceptance_date'];
			$variation_notes = $row['variation_notes'];
		}

		$invoice_q = $this->invoice_m->list_invoice($proj_id);
		foreach ($invoice_q->result_array() as $row){
			if($row['label'] !== "" && $row['label'] !== "VR"){
				$final_invoiced = $row['is_invoiced'];
			}
		}
		echo $variation_name."|".$install_time_hrs."|".$is_double_time."|".$variation_credit."|".$variation_markup."|".$acceptance_date."|".$variation_notes."|".$final_invoiced;
	}

	public function update_variation(){
		$variation_id = $_POST['variation_id'];
		$var_proj_id = $_POST['proj_id'];
		$var_name = $_POST['var_name'];
		$var_site_hrs = $_POST['var_site_hrs'];
		$var_is_double_time = $_POST['var_is_double_time'];
		$var_credit = $_POST['var_credit'];
		$var_markup = $_POST['var_markup'];
		$var_acceptance_date = $_POST['var_acceptance_date'];
		$var_notes = $_POST['var_notes'];


		$site_labour_total = $this->variation_labor_cost($var_proj_id,$var_site_hrs,$var_is_double_time,$var_markup);

		$var_q = $this->variation_m->display_selected_variation($variation_id);
		foreach ($var_q->result_array() as $row){
			$variation_cost = $row['variation_cost'];
		}

		$variation_total = ($site_labour_total + $variation_cost) - $var_credit;

		$this->variation_m->update_variation($var_proj_id,$var_name,$var_site_hrs,$var_is_double_time,$site_labour_total,$var_credit,$variation_total,$var_markup,$var_acceptance_date,$variation_id,$var_notes);

		$data['var_q'] = $this->variation_m->display_all_variation($var_proj_id);
		$this->load->view('proj_variation_list', $data);
	}

	public function delete_variation(){
		$variation_id = $_POST['variation_id'];
		$var_proj_id = $_POST['proj_id'];

		$this->variation_m->delete_variation($variation_id);

		$data['var_q'] = $this->variation_m->display_all_variation($var_proj_id);
		$this->load->view('proj_variation_list', $data);
	}

	public function view_variation_works(){
		// $project_id = $this->uri->segment(3);

		// $q_proj = $this->projects_m->fetch_project_details($project_id);
		// if($q_proj->num_rows > 0){
		// 	$data = array_shift($q_proj->result_array());
		// 	$projid = $data['project_id'];
		// }else{
		// 	$data['error'] = 'Unable to locate record';
		// }

		// $proj_q = $this->projects_m->select_particular_project($project_id);
		// foreach ($proj_q->result_array() as $row){
		// 	$data['job_date'] = $row['job_date'];
		// }

		// $data['projid'] = $projid;
		// $data['screen'] = "Variation";
		// $this->load->view('variation_works_v',$data);



		$project_id = $this->uri->segment(3);
		$variation_id = $this->uri->segment(4);
		$this->session->set_flashdata('curr_tab', 'variations');
		$this->session->set_flashdata('variation', 'variation');
		$this->session->set_flashdata('variation_id', $variation_id);
		redirect('/projects/view/'.$project_id);
		//$this->works->works_view();
	}

	public function back_to_variations(){
		$this->session->set_flashdata('curr_tab', 'variations');
	}

	public function view_variation_joinery(){
		$project_id = $_POST['proj_id'];
		$variation_id = $_POST['var_id'];
		$this->session->set_flashdata('curr_tab', 'variations');
		$this->session->set_flashdata('variation', 'variation');
		$this->session->set_flashdata('variation_id', $variation_id);
	}

	public function variation_works_view(){
		$variation_id = $this->uri->segment(4);
		$this->session->set_flashdata('variation_id', $variation_id);
		$this->works->variations_view();
	}

	public function get_variation_total(){
		$proj_id = $_POST['proj_id'];
		$var_total_arr = $this->variation_m->fetch_variation_total($proj_id);
		$var_total_arr = explode("|", $var_total_arr);
		$accepted_total = number_format($var_total_arr[0]);
		$unaccepted_total = number_format($var_total_arr[1]);

		echo $accepted_total."|".$unaccepted_total;
	}
}