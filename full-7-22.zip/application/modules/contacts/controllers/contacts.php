<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Contacts extends MY_Controller{
	
	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');		
		$this->load->module('users'); 
		$this->load->module('company'); 
		$this->load->model('company_m');
		$this->load->model('contacts_m');
		if($this->session->userdata('is_admin') == 1 ):		
			$this->load->module('admin');
		endif;	
		if(!$this->users->_is_logged_in() ): 		
			redirect('', 'refresh');
		endif;
	}
	
	public function index(){
		$this->users->_check_user_access('company',1);
		$data['main_content'] = 'contacts_v';
		$data['new_compamy_id'] = $this->session->userdata('item');
		$data['comp_type'] = 1;
		$data['screen'] = 'Contacts';
		$this->load->view('page', $data);
	}	

	public function display_contacts($contact_type){
		if($contact_type==0):
			$data['cont_c'] = $this->contacts_m->fetch_contacts();
		else:
			$data['cont_c'] = $this->contacts_m->fetch_contacts_by_company_type($contact_type);
		endif;
		$this->load->view('contacts_t',$data);
	}

	public function display_selected_contacts(){
		$contact_person_id = $_POST['contact_person_id'];
		
		$contact_person_q = $this->contacts_m->fetch_contacts_by_id($contact_person_id);
		foreach ($contact_person_q->result_array() as $row){
			$contact_name = $row['first_name']." ".$row['last_name'];
			$contact_comp = $row['company_name'];
			$contact_comp_state = $row['name']." (".$row['shortname'].")";
			$contact_comp_suburb = $row['suburb'];
			if($row['office_number'] == ""):
				$office_number = "";
			else:
				$office_number = "(".$row['area_code'].") ".$row['office_number'];
			endif;
			$mobile_number = $row['mobile_number'];
			$email = $row['general_email'];
			if($row['company_type_id'] == 2):
				$description = $row['job_category'];
			else:
				$description = $row['supplier_cat_name'];
			endif;
		}	
		echo $contact_name."|".$contact_comp."|".$contact_comp_state."|".$contact_comp_suburb."|".$office_number."|".$mobile_number."|".$email."|".$description;
	}
}