<?php

class Contacts_m extends CI_Model{
	
	public function fetch_contacts(){		
		$query = $this->db->query("select a.*,b.company_name,b.company_type_id, c.first_name, c.last_name, d.general_email, e.*, f.*, g.*,h.suburb,i.shortname
						from contact_person_company a 
						Left join company_details b on a.company_id = b.company_id 
						left join contact_person c on a.contact_person_id = c.contact_person_id 
						left join email d on c.email_id = d.email_id 
						left join contact_number e on c.contact_number_id = e.contact_number_id 
						left join job_category f on f.job_category_id = b.activity_id
						left join supplier_cat g on g.supplier_cat_id = b.activity_id
						left join address_detail j on j.address_detail_id = b.address_id
						left join address_general h on h.general_address_id = j.general_address_id
						left join states i on i.id = h.state_id
						order by c.first_name");		
		return $query;
	}

	public function fetch_contacts_by_company_type($contact_type){		
		$query = $this->db->query("select a.*,b.company_name,b.company_type_id, c.first_name, c.last_name, d.general_email, e.*, f.*, g.*,h.suburb,i.shortname
							from contact_person_company a 
							Left join company_details b on a.company_id = b.company_id 
							left join contact_person c on a.contact_person_id = c.contact_person_id 
							left join email d on c.email_id = d.email_id 
							left join contact_number e on c.contact_number_id = e.contact_number_id 
							left join job_category f on f.job_category_id = b.activity_id
							left join supplier_cat g on g.supplier_cat_id = b.activity_id
							left join address_detail j on j.address_detail_id = b.address_id
							left join address_general h on h.general_address_id = j.general_address_id
							left join states i on i.id = h.state_id
							where company_type_id = '$contact_type'
							order by c.first_name");		
		return $query;
	}

	public function fetch_contacts_by_id($contact_id){		
		$query = $this->db->query("select a.*,b.company_name,b.company_type_id, c.first_name, c.last_name, d.general_email, e.*, f.*, g.*,h.suburb,i.name,i.shortname
							from contact_person_company a 
							Left join company_details b on a.company_id = b.company_id 
							left join contact_person c on a.contact_person_id = c.contact_person_id 
							left join email d on c.email_id = d.email_id 
							left join contact_number e on c.contact_number_id = e.contact_number_id 
							left join job_category f on f.job_category_id = b.activity_id
							left join supplier_cat g on g.supplier_cat_id = b.activity_id
							left join address_detail j on j.address_detail_id = b.address_id
							left join address_general h on h.general_address_id = j.general_address_id
							left join states i on i.id = h.state_id
							where a.contact_person_id = '$contact_id'
							order by c.first_name");		
		return $query;
	}
}