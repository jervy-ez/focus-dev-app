<div class="col-sm-12 col-md-1 col-lg-1 tour-2" id="leftCol" >
	<div class="nav nav-stacked affix-top" id="sidebar">
		<div class="side-tools clearfix"  id="my-other-element">
			<ul>
				<li>
					<a href="<?php echo base_url(); ?>"> <i class="fa fa-tachometer fa-3x"></i> <label class="control-label">Dashboard</label> </a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>company"> <i class="fa fa-users fa-3x"></i> <label class="control-label">Company</label></a>
				</li>
				<li>
					<a href="<?php echo base_url(); ?>projects"> <i class="fa fa-map-marker fa-3x"></i> <label class="control-label">Projects</label></a>
				</li>
				<li>
					<a href="#"> <i class="fa fa-tasks fa-3x"></i> <label class="control-label">WIP</label></a>
				</li>
				<li>
					<a href="#"> <i class="fa fa-list-alt fa-3x"></i> <label class="control-label">Invoice</label></a>
				</li>
				<li>
					<a href="#"> <i class="fa fa-bar-chart-o fa-3x"></i> <label class="control-label">Reports</label></a>
				</li>
				<li>
					<a href="#" class=""> <i class="fa fa-cogs fa-3x"></i> <label class="control-label">Settings</label></a>
				</li>
			</ul>
		</div>
	</div>
</div>