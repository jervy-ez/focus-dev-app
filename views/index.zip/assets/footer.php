	<div class="container-fluid">
		<div class="row">	
			<footer>
				<hr />
				<p class="text-center">&copy; Focus Shopfit 2014</p>
			</footer>
		</div>
	</div>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.0.min.js"><\/script>')</script>
	<script src="<?php echo base_url(); ?>js/vendor/bootstrap.min.js"></script>	
	
	<?php //if($chart): ?>
	<script src="<?php echo base_url(); ?>js/c3/charts.js"></script>
	<?php //endif; ?>
	
	<?php //if($tour): ?>
	<script src="<?php echo base_url(); ?>js/bootstrap-tour.min.js"></script>
	<link href="<?php echo base_url(); ?>css/bootstrap-tour.min.css" rel="stylesheet">
	<script src="<?php echo base_url(); ?>js/tour.js"></script>
	<?php //endif; ?>
	
	<?php //if($table): ?>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/dataTables.bootstrap.css">
	<script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>js/datatables/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>js/datatables/dataTables.bootstrap.js"></script>
	<script src="<?php echo base_url(); ?>js/datatables/table.js"></script>
	<?php //endif; ?>
	
	<?php //if($maps): ?>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/maps/maps.js"></script>
    <?php //endif; ?>    
    
	<link href="<?php echo base_url(); ?>css/select2.css" rel="stylesheet"/>
	<script src="<?php echo base_url(); ?>js/select2.js"></script>
    
	<script src="<?php echo base_url(); ?>js/plugins.js"></script>
	<script src="<?php echo base_url(); ?>js/main.js"></script>
	
	
<script language="JavaScript"> 	
   	
   	var controller = 'company';
    var base_url = '<?php echo site_url(); //you have to load the "url_helper" to use this function ?>';
	
	//load_data_ajax
	function load_data_ajax(suburbState,sufx){
		var val = suburbState.split("-");
    	$.ajax({
        	'url' : base_url + controller + '/get_list_view',
            'type' : 'POST', //the way you want to send data to your URL
            'data' : {'suburb' : val[0],'state':val[1],'phonecode':val[2] },
            'success' : function(data){ //probably this request will return anything, it'll be put in var "data"
            	var state = $('#state_'+sufx); //jquery selector (get element by id)
            	var areacode = $('#areacode');
            	var postcode = $('#postcode_'+sufx);            	
                if(data){
                	var valuesData = data.split("|");
                	//alert(valuesData[1]);
                	state.disabled=false;
                	state.val(valuesData[1]);
                	//state.readonly=true;
                	
                	areacode.val(valuesData[2]);
                	postcode.html(valuesData[0]);
            	}
        	}
    	});
	}
	//load_data_ajax

	//dynamic_value_ajax
	function dynamic_value_ajax(value,method,classLocation){
    	$.ajax({
        	'url' : base_url+controller+'/'+method,
            'type' : 'POST',
            'data' : {'ajax_var' : value },
            'success' : function(data){
            	var divLocation = $(classLocation);
                if(data){
                	divLocation.html(data);
            	}
        	}
    	});
   }
   //dynamic_value_ajax

	$(".suburb-option-a").on("change", function(e) {
   		//alert($(this).val());
   		//alert('test');
   		load_data_ajax($(this).val(),'a');
   	}); //this is working select callbak!
   	   	
   	$(".suburb-option-b").on("change", function(e) {
   		load_data_ajax($(this).val(),'b');
   	}); 
   
   	$("#type").on("change", function(e) {
   		dynamic_value_ajax($(this).val(),'activity','.activity');
   		//alert($(this).val());
   	}); 
   	
   	
   	$('#contactperson').on("change", function(e){   		
   		if($(this).val() == 'add'){
   			$('#add_contact').modal('show');
   		}
   	}); //this is working select callbak!

</script>

	
</body>
</html>
