
	
	<div class="row">
		<div class="span6 offset3">
			<h1>Success</h1>
					
			<div class="well">
				<p>Lorem ipsum!!!</p>
			</div>
		</div>
	</div>
