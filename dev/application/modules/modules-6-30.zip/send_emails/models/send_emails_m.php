<?php

class Send_emails_m extends CI_Model{
	public function display_project_forms($projid){
		$query = $this->db->query("select * from projects_forms where project_id = '$projid'");
		return $query;
	}

	public function insert_project_forms($projid,$description){
		$date_modified = date('d/m/Y');
		$query = $this->db->query("INSERT INTO projects_forms (project_id,description,date_modified,status) values('$projid','$description','$date_modified','Created')");
	}

	public function update_project_forms($projid,$form_name){
		$date_modified = date('d/m/Y');
		$query = $this->db->query("UPDATE projects_forms set date_modified = '$date_modified', status ='Modified' where project_id = '$projid' and description = '$form_name'");
		return $query;
	}

	public function display_selected_project_forms($projects_forms_id){
		$query = $this->db->query("select * from projects_forms where projects_forms_id = '$projects_forms_id'");
		return $query;
	}
}