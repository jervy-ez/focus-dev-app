<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Attachments extends MY_Controller{
	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');	
		$this->load->module('users');
		$this->load->module('company');
		$this->load->model('attachments_m');
		if($this->session->userdata('is_admin') == 1 ):		
			$this->load->module('admin');
		endif;
		$this->load->module('projects');

		$this->load->helper(array('form', 'url','html'));
		//$this->load->model('project_m');
	}
	function index(){
	}

	function attachments_view(){
		$data['project_id'] = $this->uri->segment(3);
		$this->load->view('attachment_v',$data);
	}

	function display_project_attachments(){
		$proj_id = $this->uri->segment(3);
		$data['proj_attachment_t'] = $this->attachments_m->display_selected_project_attachments($proj_id);
		$this->load->view('table_project_attachment', $data);

	}

	function view_attachment_type(){
		$type = $_POST['type'];
		$attachment_type_q = $this->attachments_m->display_all_attachment_type();
		switch($type){
			case 1:
				foreach ($attachment_type_q->result_array() as $row){
					echo '<option value="'.$row['attachment_type_id'].'">' . $row['attachment_type'] . "</option>";
				}
				echo '<option value="Add_New">Add New</option>';
				break;
			case 2:
				echo '<table class="table table-striped table-bordered" cellspacing="0" width="100%">';
				echo '<thead><tr><th>Attachment Type</th></tr></thead><tbody>';
				foreach ($attachment_type_q->result_array() as $row){
					echo '<tr><td id = "attachment_cell_'.$row['attachment_type_id'].'" onclick = "select_attachment_type('.$row['attachment_type_id'].')">' . $row['attachment_type'] . '</td></tr>';
				}			
				echo '</tbody></table>';
				break;
			case 3:
				$x = 1;
				foreach ($attachment_type_q->result_array() as $row){
					$y = 0;
				?>
				<label style = "width: 25%"><input type = "checkbox" name = "chck_attachment_type[]" value = "<?php echo $row['attachment_type_id']?>" <?php while($y <= $this->session->userdata('attachment_num')) { if($this->session->userdata($y) == $row['attachment_type_id']){ echo 'checked';} $y++; } ?> ><?php echo $row['attachment_type'] ?></label>
				<?php
					if(($x%4)== 0){
						echo "</br>";
					}
					$x++;
				}
				break;
			case 4:
				foreach ($attachment_type_q->result_array() as $row){
					echo '<p><input type = "checkbox" name = "chck_attachment_type[]" value = "'.$row['attachment_type_id'].'">  '.$row['attachment_type'].'</p>';
				}
				break;
			case 5:
				foreach ($attachment_type_q->result_array() as $row){
					echo '<option value="'.$row['attachment_type_id'].'">' . $row['attachment_type'] . "</option>";
				}
				break;
		}
		
	}

	function view_attachment_type_list(){
		$attachment_type_q = $this->attachments_m->display_all_attachment_type();
		foreach ($attachment_type_q->result_array() as $row){
			echo '<option value="'.$row['attachment_type_id'].'">' . $row['attachment_type'] . "</option>";
		}
	}
	function fetch_selected_proj_attachment(){
		$project_attachments_id = $_POST['project_attachments_id'];
		$proj_attach_q = $this->attachments_m->display_selected_attachment($project_attachments_id);
		foreach ($proj_attach_q->result_array() as $row){
			$file_name = $row['project_attachments_url'];
		}
		echo $file_name;
	}

	function edit_attachment_type(){
		$project_attachments_id = $_POST['project_attachments_id'];
    	$attach_type = $_POST['attach_type'];
    	$this->attachments_m->update_project_attachment_type($attach_type,$project_attachments_id);
	}

	function insert_attachment_type(){
		$attachment_type = $_POST['attachment_type'];
		$this->attachments_m->insert_attachment_type($attachment_type);
	}
	function update_attachment_type(){
		$attachment_type = $_POST['attachment_type'];
		$project_attachment_id = $_POST['project_attachment_id'];
		$this->attachments_m->update_attachment_type($attachment_type,$project_attachment_id);
	}
	function attachment_isselected(){
		$proj_attachment_status = $_POST['proj_attachment_status'];
		$project_attachment_id = $_POST['project_attachments_id'];
		$this->attachments_m->update_project_attachment_status($proj_attachment_status,$project_attachment_id);
	}
	function attachment_type_verfication(){
		$proj_id = $this->uri->segment(3);
		$project_attachment_id = $_POST['project_attachment_id'];
		$proj_attachment_q = $this->attachments_m->display_all_project_attachments();
		$exist = 0;
		foreach ($proj_attachment_q->result_array() as $row){
			if($row['attachment_type_id'] == $project_attachment_id){
				$exist = $exist + 1;
			}
		};
		if($exist == 0){
			$this->attachments_m->delete_attachment_type($project_attachment_id);
			echo 1;
			
		}else{
			echo "Cannot Delete, Attachement Type has already been used by 1 or more project attachements";
		}
	}

	function do_upload()
	{
		$project_id = $this->uri->segment(3);
		$attachment_type = $_POST['attachment_type'];

	    $this->load->library('upload');

	    $files = $_FILES;
	    $cpt = count($_FILES['userfile']['name']);
	    for($i=0; $i<$cpt; $i++)
	    {
	    	$file_name =  $files['userfile']['name'][$i];
	    	$file_name = str_replace(' ', '_', $file_name);
	    	$proj_attach_q = $this->attachments_m->display_selected_project_attachments($project_id);
	    	$file = explode('.', $file_name);
	    	$filename = $file[0];
	    	$extension = $file[1];
	    	$file_exist = 0;
	    	foreach ($proj_attach_q->result_array() as $row){
	    		$db_file_name = $row['project_attachments_url'];
	    		$db_file = explode('.', $db_file_name);
		    	$db_filename = $db_file[0];
		    	$db_extension = $db_file[1];
		    	if (strpos($db_filename, $filename) !== false) {
		    		if($extension == $db_extension){
		    			$file_exist = $file_exist + 1;
		    		}	
		    	}
	    	}

	    	if($file_exist > 0){
	    		$filename = $filename.$file_exist;
	    		$file_name = $filename.".".$extension;
	    	}

		    $_FILES['userfile']['name']= $file_name;
		    $_FILES['userfile']['type']= $files['userfile']['type'][$i];
		    $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
		    $_FILES['userfile']['error']= $files['userfile']['error'][$i];
		    $_FILES['userfile']['size']= $files['userfile']['size'][$i];    

		    $this->upload->initialize($this->set_upload_options($project_id));
		    $this->upload->do_upload();
	    	$this->attachments_m->insert_proj_attachments($project_id,$attachment_type,$_FILES['userfile']['name']);
	    }
	    $this->session->set_flashdata('curr_tab', 'attachments');
	    redirect('projects/view/'.$project_id);
	}
	private function set_upload_options($proj_id)
	{   
	//  upload an image options
		$path = "./uploads/project_attachments/".$proj_id;
		mkdir($path, 0755, true);
	    $config = array();
	    $config['upload_path'] = $path."/";
	    $config['allowed_types'] = '*';
	    $config['max_size']      = '0';
	    $config['overwrite']     = FALSE;


	    return $config;
	}
}
?>