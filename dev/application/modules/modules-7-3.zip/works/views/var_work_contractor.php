<table class="table table-striped table-bordered" style = "font-size: 11px">
	<thead>
		<tr>
			<th>Requested Quotes</th>
			<th>Price ex GST</th>
			<th>Inc GST</th>
		</tr>
	</thead>
	<tbody>
		<?php
		if($works_contructors_t->num_rows == 0){
		?>
		<tr>
			<td colspan = 3>
		<?php
			echo "No Contructor Selected";
		?>
			</td>
		</tr>
		<?php
		}else{
			foreach ($works_contructors_t->result_array() as $row){
				$is_selected = $row['is_selected'];
			?>
			<tr class="cont-<?php echo $row['works_contrator_id']; ?>" <?php if($is_selected == 1){ ?>style = "color: #CC6666"<?php } ?>>
				<td class="item-cont-<?php echo $row['works_contrator_id']; ?>-comp">
					<?php if($job_date !== ""): ?>
						<?php if($acceptance_date !== ""): ?>
							<input type="radio" id = "selcomp" name = "selcomp" value = "<?php echo $row['works_contrator_id'] ?>" <?php if($is_selected == 1){ ?>checked="checked"<?php } ?> onClick = "sel_var_work_con(<?php echo $row['works_contrator_id'] ?>)" >
						<?php endif; ?>
					<?php endif; ?>
					<a href="#" <?php if($is_variation == 0){ ?>onClick = "selcontractor(<?php echo $row['works_contrator_id'] ?>)" data-toggle="modal" data-target="#addContractor_Modal"<?php }else{ ?> onClick = "sel_var_contractor(<?php echo $row['works_contrator_id'] ?>)" data-toggle="modal" data-target="#add_var_Contractor_Modal"<?php }?>><?php echo $row['company_name'] ?></a>
				</td>
				<td class="item-cont-<?php echo $row['works_contrator_id']; ?>-exprce" align = right>
					<input type="text" onclick = "this.select()" onkeyup = "ku_update_exgst(<?php echo $row['works_contrator_id']; ?>)" onblur = "update_exgst(<?php echo $row['works_contrator_id']; ?>)" class="work-set-exgst-<?php echo $row['works_contrator_id']; ?> input_text text-right number_format price" value = "<?php echo number_format($row['ex_gst'],2) ?>" style = "width: 100%">
				</td>
				<td class="item-cont-<?php echo $row['works_contrator_id']; ?>-incprice" align = right>
					<input type="text" onclick = "this.select()" onkeyup = "ku_update_incgst(<?php echo $row['works_contrator_id']; ?>)" onblur = "update_incgst(<?php echo $row['works_contrator_id']; ?>)" class="work-set-incgst-<?php echo $row['works_contrator_id']; ?> input_text text-right number_format price" value = "<?php echo number_format($row['inc_gst'],2) ?>" style = "width: 100%">
				</td>
			</tr>
			<?php
			}
		}
		?>
	</tbody>
</table>